import pandas as pd

data = pd.read_excel('excel.xlsx')

data