package com.mycompany.smartai;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class ChatFrame extends JFrame {

    private boolean isFirstMessage = true;

    private int userId;
    private int chatId;

    private JTextArea chatArea;
    private JTextField messageField;

    private JList<String> historyList;
    private DefaultListModel<String> historyModel;

    private JTextField searchField;

    public ChatFrame(String username) {

        this.userId = DatabaseManager.getUserId(username);
        this.chatId = -1;

        setTitle("SmartAI - " + username);
        setSize(900, 550);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // ================= LEFT PANEL =================
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setPreferredSize(new Dimension(260, 0));

        JButton newChatButton = new JButton("New Chat");
        JButton deleteButton = new JButton("Delete Chat");

        searchField = new JTextField();

        JPanel topPanel = new JPanel(new GridLayout(3, 1, 5, 5));
        topPanel.add(newChatButton);
        topPanel.add(searchField);
        topPanel.add(deleteButton);

        historyModel = new DefaultListModel<>();
        historyList = new JList<>(historyModel);
        historyList.setFocusable(false);

        leftPanel.add(topPanel, BorderLayout.NORTH);
        leftPanel.add(new JScrollPane(historyList), BorderLayout.CENTER);

        // ================= CHAT AREA =================
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        chatArea.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                messageField.requestFocusInWindow();
            }
        });

        JScrollPane chatScroll = new JScrollPane(chatArea);

        // ================= INPUT AREA =================
        messageField = new JTextField();
        messageField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        messageField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("Type your message here..."),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        messageField.setEditable(true);
        messageField.setEnabled(true);
        messageField.setFocusable(true);

        JButton sendButton = new JButton("Send");
        JButton logoutButton = new JButton("Logout");

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.add(sendButton);
        btnPanel.add(logoutButton);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(messageField, BorderLayout.CENTER);
        bottomPanel.add(btnPanel, BorderLayout.EAST);

        // ================= SPLIT PANE =================
        JSplitPane splitPane = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                leftPanel,
                chatScroll
        );
        splitPane.setDividerLocation(260);

        setLayout(new BorderLayout());
        add(splitPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // ================= EVENTS =================
        sendButton.addActionListener(e -> sendMessage());
        messageField.addActionListener(e -> sendMessage());

        newChatButton.addActionListener(e -> {
            chatArea.setText("");
            chatId = -1;
            isFirstMessage = true;
            messageField.requestFocusInWindow();
        });

        deleteButton.addActionListener(e -> {
            deleteChat();
            messageField.requestFocusInWindow();
        });

        searchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                searchChats(searchField.getText());
            }
        });

        logoutButton.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });

        loadChatHistory();
        setVisible(true);

        // ================= FOCUS FIX =================
        SwingUtilities.invokeLater(() -> {
            messageField.grabFocus();
            messageField.requestFocus();
        });
    }

    // ================= SEND MESSAGE =================
    private void sendMessage() {

        String message = messageField.getText().trim();
        if (message.isEmpty()) return;

        chatArea.append("You: " + message + "\n");
        messageField.setText("");

        if (isFirstMessage) {
            chatId = DatabaseManager.createChat(userId, generateTitle(message));
            loadChatHistory();
            isFirstMessage = false;
        }

        new Thread(() -> {
            try {
                String reply = getReply(message);

                SwingUtilities.invokeLater(() -> {
                    chatArea.append("SmartAI: " + reply + "\n\n");
                    chatArea.setCaretPosition(chatArea.getDocument().getLength());
                    messageField.requestFocusInWindow();
                });

                DatabaseManager.saveMessage(chatId, message, reply);

            } catch (Exception ex) {
                ex.printStackTrace();
                SwingUtilities.invokeLater(() -> {
                    chatArea.append("SmartAI: Error getting response.\n\n");
                    messageField.requestFocusInWindow();
                });
            }
        }).start();
    }

    // ================= GEMINI API =================
    private String getReply(String message) {

        try {
            String apiKey = "AIzaSyAxen7rvwYcqPpeMswKlKw474RkqrzORJs";

            String apiUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + apiKey;
            String body = "{"
                + "\"contents\":[{"
                + "\"parts\":[{"
                + "\"text\":\"" + message.replace("\"", "'") + "\""
                + "}]"
                + "}]"
                + "}";

            java.net.URL url = new java.net.URL(apiUrl);
            java.net.HttpURLConnection conn =
                    (java.net.HttpURLConnection) url.openConnection();

            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            try (java.io.OutputStream os = conn.getOutputStream()) {
                os.write(body.getBytes("utf-8"));
            }

            int responseCode = conn.getResponseCode();
            System.out.println("Response code: " + responseCode);

            java.io.InputStream is = (responseCode >= 200 && responseCode < 300) 
                ? conn.getInputStream() 
                : conn.getErrorStream();

            java.io.BufferedReader br =
                    new java.io.BufferedReader(
                            new java.io.InputStreamReader(is, "utf-8"));

            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

            String json = sb.toString();
            System.out.println("API Response: " + json);

            java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(
                "\"text\":\\s*\"((?:[^\"\\\\]|\\\\.)*)\"");
            java.util.regex.Matcher matcher = pattern.matcher(json);

            if (matcher.find()) {
                return matcher.group(1)
                    .replace("\\n", "\n")
                    .replace("\\\"", "\"")
                    .replace("\\\\", "\\");
            }

            return "API Error: " + json;

        } catch (Exception e) {
            e.printStackTrace();
            return "Error: " + e.getMessage();
        }
    }

    // ================= CHAT TITLE =================
    private String generateTitle(String msg) {
        return msg.length() > 25 ? msg.substring(0, 25) + "..." : msg;
    }

    // ================= HISTORY =================
    private void loadChatHistory() {

        historyModel.clear();

        List<String[]> chats = DatabaseManager.getChats(userId);

        for (String[] c : chats) {
            historyModel.addElement("Chat " + c[0] + " - " + c[1]);
        }
    }

    private void searchChats(String key) {

        historyModel.clear();

        List<String[]> chats = DatabaseManager.getChats(userId);

        for (String[] c : chats) {
            if (c[1].toLowerCase().contains(key.toLowerCase())) {
                historyModel.addElement("Chat " + c[0] + " - " + c[1]);
            }
        }
    }

    private void deleteChat() {

        String sel = historyList.getSelectedValue();
        if (sel == null) return;

        int id = Integer.parseInt(sel.split("-")[0].replace("Chat", "").trim());

        DatabaseManager.deleteChat(id);

        loadChatHistory();
        chatArea.setText("");
        chatId = -1;
        isFirstMessage = true;
    }
}